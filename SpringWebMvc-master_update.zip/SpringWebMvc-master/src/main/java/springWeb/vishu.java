package springWeb;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
@Controller
public class vishu {
	@RequestMapping("/home")
	public String getHome() {
		return "home";
	}
	
	@RequestMapping("/")
	public String getRoot() {
		return "index";
	}
}
